# face_rec
An eye-blink detection-based face liveness detection algorithm to thwart photo attacks.
Read more on: https://towardsdatascience.com/real-time-face-liveness-detection-with-python-keras-and-opencv-c35dc70dafd3
